﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace adminBibliotecaUI.Forms
{
    public partial class bibliotecaLibros : Form
    {
        private List<Libros> libros = new List<Libros>();
        private List<Autor> usuarios = new List<Autor>();
        public bibliotecaLibros()
        {
            InitializeComponent();
        }

        private void bibliotecaLibros_Load(object sender, EventArgs e)
        {
            Autor autor1 = new Autor("Bram Stoker");
            Autor autor2 = new Autor("William Shakespeare");
            Autor autor3 = new Autor("Giovanni Boccaccio");
            Autor autor4 = new Autor("Charles Dickens");
            Autor autor5 = new Autor("Ralph Ellison");
            Autor autor6 = new Autor("Homero");

            libros.Add(new Libros("01", "ISBN001", "Dracula", autor1, 2000, 10, Libros.EstadoLibro.Disponible, null));
            libros.Add(new Libros("02", "ISBN003", "Romeo y Julieta", autor2, 2010, 5, Libros.EstadoLibro.Disponible, null));
            libros.Add(new Libros("03", "ISBN003", "Decamerón", autor3, 2000, 10, Libros.EstadoLibro.Prestado, null));
            libros.Add(new Libros("04", "ISBN004", "Grandes Esperanzas", autor4, 2010, 5, Libros.EstadoLibro.Disponible, null));
            libros.Add(new Libros("05", "ISBN005", "El hombre invisible", autor5, 2000, 10, Libros.EstadoLibro.Vendido, null));
            libros.Add(new Libros("06", "ISBN006", "Ilíada", autor6, 2010, 5, Libros.EstadoLibro.Disponible, null));

            //Actualizar listas
            UpdateLibrosListBox();
            UpdateUsuariosComboBox();
        }
        private void UpdateLibrosListBox()
        {
            listBoxLibros.Items.Clear();
            foreach (var libro in libros)
            {
                listBoxLibros.Items.Add(libro);
            }
        }
        private void UpdateUsuariosComboBox()
        {
            listBoxLibros.Items.Clear();
            foreach (var usuario in usuarios)
            {
                listBoxLibros.Items.Add(usuario);
            }
        }

        private void agregarBtn_Click(object sender, EventArgs e)
        {
            // Verificar campos vacíos
            if (string.IsNullOrEmpty(textBoxID.Text) ||
                string.IsNullOrEmpty(textBoxISBN.Text) ||
                string.IsNullOrEmpty(textBoxNombre.Text) ||
                string.IsNullOrEmpty(textBoxAutor.Text) ||
                string.IsNullOrEmpty(textBoxAnio.Text) ||
                string.IsNullOrEmpty(textBoxCantidad.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos antes de agregar un nuevo libro.", "Campos vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            //Agregar un nuevo libro
            Autor autor = new Autor(textBoxAutor.Text);
            Libros libro = new Libros(
                textBoxID.Text,
                textBoxISBN.Text,
                textBoxNombre.Text,
                autor,
                Convert.ToInt32(textBoxAnio.Text),
                Convert.ToInt32(textBoxCantidad.Text),
                Libros.EstadoLibro.Disponible,
                null
            );

            libros.Add(libro);
            UpdateLibrosListBox();
        }

        private void prestarBtn_Click(object sender, EventArgs e)
        {
            if (listBoxLibros.SelectedItem != null && listBoxLibros.SelectedItem != null)
            {
                Libros libroSeleccionado = (Libros)listBoxLibros.SelectedItem;

                if (libroSeleccionado.Estado == Libros.EstadoLibro.Disponible)
                {
                    libroSeleccionado.Estado = Libros.EstadoLibro.Prestado;
                    libroSeleccionado.fechaRetorno = DateTime.Now.AddDays(14); // ejemplo: préstamo de 2 semanas.
                    UpdateLibrosListBox();
                }
                else
                {
                    MessageBox.Show("El libro seleccionado no está disponible para préstamo.");
                }
            }
        }

        private void comprarBtn_Click(object sender, EventArgs e)
        {
            if (listBoxLibros.SelectedItem != null)
            {
                Libros libroSeleccionado = (Libros)listBoxLibros.SelectedItem;

                if (libroSeleccionado.Estado == Libros.EstadoLibro.Disponible)
                {
                    MessageBox.Show("Compra realizada con éxito.");
                }
                else
                {
                    MessageBox.Show("El libro seleccionado no está disponible para compra.");
                }
            }
        }
    }
}
