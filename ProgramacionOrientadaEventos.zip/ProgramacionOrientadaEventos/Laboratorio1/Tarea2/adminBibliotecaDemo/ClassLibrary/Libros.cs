﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Autor
    {
        public string Nombre { get; }

        public Autor(string nombre)
        {
            Nombre = nombre;
        }

        public override string ToString()
        {
            return Nombre;
        }
    }
    public class Libros
    {
        public enum EstadoLibro { Disponible, Prestado, Vendido }

        public string ID { get; }
        public string ISBN { get; }
        public string Nombre { get; }
        public Autor Autor { get; }
        public int anioPublicacion { get; }
        public int cantidadInventario { get; }
        public EstadoLibro Estado { get; set; }
        public Usuario UsuarioPrestamo { get; set; }
        public DateTime? fechaRetorno { get; set; }

        public Libros(string id, string isbn, string nombre, Autor autor, int anio, int cantidad, EstadoLibro estado, Usuario usuarioPrestamo)
        {
            ID = id;
            ISBN = isbn;
            Nombre = nombre;
            Autor = autor;
            anioPublicacion = anio;
            cantidadInventario = cantidad;
            Estado = estado;
            UsuarioPrestamo = usuarioPrestamo;
        }

        public override string ToString()
        {
            return $"{Nombre} - {Estado}";
        }
        public class Usuario
        {
            public string Nombre { get; }

            public Usuario(string nombre)
            {
                Nombre = nombre;
            }
            public override string ToString()
            {
                return Nombre;
            }
        }
    }
}

